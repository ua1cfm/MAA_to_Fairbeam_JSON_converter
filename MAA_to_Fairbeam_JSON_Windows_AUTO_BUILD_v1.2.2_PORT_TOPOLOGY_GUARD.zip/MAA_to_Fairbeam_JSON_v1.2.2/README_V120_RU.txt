MAA → Fairbeam v1.2.0, UA1CFM 2026

НОВОЕ: Эквивалент последовательного сопротивления потерь L/C при заданной Q только на проектной частоте f0: Rs=abs(omega*L-1/(omega*C))/Q. Это не широкополосная эквивалентность MMANA и не замена импульсной топологии. Сохранена диагностика неподдержанных B/E автоматической сегментации, диагональных и многопортовых возбуждений.

Big Star: экспорт катушки с Rs; порт W17C отсутствует из-за геометрического короткого замыкания, simulation_ready=false. 144omni: W13B не экспортируется при сегментации -1; simulation_ready=false.

Проверки: python -m unittest -q test_converter.py test_pulse_positions.py
Для Windows: BUILD_EXE_WINDOWS.bat. Нужен Python с tkinter и интернет при сборке PyInstaller. Запуска Fairbeam/openEMS в этом архиве нет.
