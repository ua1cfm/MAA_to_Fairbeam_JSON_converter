# -*- coding: utf-8 -*-
import json
import tempfile
import unittest
from pathlib import Path
from maa_to_fairbeam import parse_maa, build_design, process_batch, validate_design


def maa(wires, sources, loads, frequency='14.05'):
    return ('\n'.join(['TEST','*',frequency,'***Wires***',str(len(wires)),*wires,
      '***Source***',f'{len(sources)},0',*sources,
      '***Load***',f'{len(loads)},1',*loads,
      '***Segmentation***','400,40,2.0,2','***G/H/M/R/AzEl/X***','0,0,1,50,120,60,0','']))


class TestConverter(unittest.TestCase):
    def convert(self, raw):
        model=parse_maa(raw.encode('utf8'),'test.maa')
        d,n,p,w=build_design(model, Path('test.maa'), 5.0)
        validate_design(d,n)
        return d,w

    def test_single_source_gap_and_copyright(self):
        d,w=self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,0,1'],[]))
        self.assertEqual(d['schema'],'fairbeam.design/1')
        self.assertEqual(len(d['ports']),1)
        self.assertEqual(d['ports'][0]['direction'],'z')
        self.assertEqual(d['ports'][0]['R'],50)
        p=d['parts'][0]['primitives']
        self.assertEqual(len(p),2)
        self.assertLess(p[0]['points'][-1][2],p[1]['points'][0][2])
        self.assertEqual(d['_maa_conversion']['original_sources'][0]['pulse'],'w1c')

    def test_port_is_line_and_ends_at_metal_faces(self):
        d, _ = self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,0,1'],[]))
        port = d['ports'][0]
        self.assertEqual(port['stop'][0] - port['start'][0], 0.0)
        self.assertEqual(port['stop'][1] - port['start'][1], 0.0)
        self.assertGreater(port['stop'][2] - port['start'][2], 0.0)
        self.assertEqual(d['_maa_conversion']['original_sources'][0]['contact_overlap_mm'], 0)

    def test_resistor_gap(self):
        d,w=self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],[],['w1c,1,110,0']))
        self.assertEqual(len(d['resistors']),1)
        self.assertEqual(d['resistors'][0]['R'],110)
        self.assertEqual(len(d['parts'][0]['primitives']),2)

    def test_multiple_mixed_loads_are_preserved_not_invented(self):
        d,w=self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,35,0.6'],
            ['w1c,0,1.7,140,350','w1b,1,8,20']))
        self.assertEqual(len(d['ports']),1)  # single nonzero feed is normalized
        self.assertEqual(len(d['resistors']),0)
        self.assertFalse(d['_maa_conversion']['simulation_ready'])
        self.assertEqual(len(d['_maa_conversion']['original_loads']),2)
        self.assertEqual(d['_maa_conversion']['original_loads'][0]['L_uH'],1.7)
        self.assertEqual(d['_maa_conversion']['original_loads'][0]['C_pF'],140)
        self.assertTrue(w)

    def test_disjoint_contiguous_subfolders_skip_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,b=Path(tmp)/'MAA',Path(tmp)/'JSON'
            for name in ['Short/Loops/L1.MAA','Yagi/Y1.maa']:
                f=a/name;f.parent.mkdir(parents=True,exist_ok=True)
                f.write_text(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,0,1'],[]))
            got=process_batch(a,b)
            self.assertEqual(got['stats']['ERROR'],0)
            self.assertEqual(got['total'],2)
            self.assertTrue((b/'Short/Loops/L1.design.json').is_file())
            self.assertTrue((b/'Yagi/Y1.design.json').is_file())
            self.assertEqual(process_batch(a,b)['stats']['SKIPPED'],2)
            self.assertEqual(process_batch(a,b,overwrite=True)['stats']['ERROR'],0)
            self.assertTrue((b/'conversion_report.csv').is_file())

    def test_diagonal_source_not_falsely_axis_aligned(self):
        d,w=self.convert(maa(['0,0,0,0.02,0,0.02,0.001,-1'],['w1c,0,1'],[]))
        self.assertEqual(d['ports'],[])
        self.assertEqual(len(d['parts'][0]['primitives']),1)
        self.assertFalse(d['_maa_conversion']['simulation_ready'])
        self.assertIn('diagonal', '; '.join(w).lower())

    def test_axial_feed_embedded_in_another_thick_tube(self):
        d,w=self.convert(maa([
            '0,0,0,0,0,0.01,0.009,-1',
            '0.005,0,0,0.005,0,0.01,0.001,-1',
        ],['w2c,0,1'],[]))
        self.assertEqual(d['ports'],[])
        self.assertEqual(len(d['parts'][0]['primitives']),2)
        self.assertIn('another metal conductor', '; '.join(w))

    def test_axial_port_validated_clear_of_metal(self):
        d,w=self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,0,1'],[]))
        self.assertTrue(d['ports'])
        self.assertTrue(d['_maa_conversion']['simulation_ready'])
        self.assertEqual(d['ports'][0]['direction'],'z')

    def test_big_star_feed_and_unmapped_lc(self):
        # Extracted physically significant dimensions from the user's
        # Big star.design.json. The 1-mm diagonal source is inside a 9-mm
        # tube, and a 0.1045-uH load was not part of the Fairbeam model.
        d,w=self.convert(maa([
            '0,0,0,0,0,0.010,0.009,-1',
            '0.010,0,0.010,0,0,0,0.001,-1',
        ],['w2c,0,1'],['w1c,0,0.1045,0,150']))
        self.assertFalse(d['ports'])
        self.assertFalse(d['_maa_conversion']['simulation_ready'])
        self.assertEqual(d['_maa_conversion']['original_loads'][0]['L_uH'],0.1045)
        self.assertIn('NOT SIMULATION READY', '; '.join(w))

    def test_big_star_real_input_audit(self):
        path = Path('/mnt/data/Big star(1).maa')
        if not path.exists():
            return
        model = parse_maa(path.read_bytes(), path.name)
        d, n, _, _ = build_design(model, Path('Big star.maa'), 5.0)
        validate_design(d, n)
        self.assertEqual(len(d['ports']), 0)
        self.assertEqual(len(d['resistors']), 0)  # conservative near-metal rejection
        audit = d['_maa_conversion']['electrical_connection_audit']
        self.assertEqual(len(audit), 3)
        self.assertEqual(audit[0]['pulse'], 'w17c')
        self.assertEqual(audit[0]['center_mm'], [5, 0, 5])
        self.assertIn(1, audit[0]['inside_other_physical_wires'])
        self.assertEqual(audit[2]['pulse'], 'w16c')
        self.assertIn(1, audit[2]['inside_other_physical_wires'])
        self.assertFalse(d['_maa_conversion']['simulation_ready'])

    def test_validator_rejects_nonaxial_legacy_port(self):
        d,w=self.convert(maa(['0,0,-1,0,0,1,0.001,-1'],['w1c,0,1'],[]))
        d['ports'][0]['stop'][0]=d['ports'][0]['start'][0]+1.0
        d['ports'][0]['stop'][1]=d['ports'][0]['start'][1]+1.0
        with self.assertRaisesRegex(Exception, 'line or sheet'):
            validate_design(d, 2)

    def test_exact_real_models(self):
        for file in ['/mnt/data/Spin_88(1).MAA','/mnt/data/DL2KQ40.maa']:
            p=Path(file)
            if p.exists():
                model=parse_maa(p.read_bytes(),p.name)
                d,n,pr,w=build_design(model,p,5.0)
                validate_design(d,n)
                self.assertEqual(len(d['_maa_conversion']['original_sources']),1)


if __name__=='__main__':
    unittest.main(verbosity=2)

class TestRlcExport(unittest.TestCase):
    def conv(self,loads):
        m=parse_maa(maa(['0,0,-1,0,0,1,0.001,-1','1,0,-1,1,0,1,0.001,-1'],['w1c,0,1'],loads).encode(),'rlc.maa')
        d,n,_,w=build_design(m,Path('rlc.maa'),5.0)
        validate_design(d,n)
        return d,w
    def test_ideal_inductor(self):
        d,_=self.conv(['w2c,0,0.15,0,0'])
        self.assertEqual(len(d['resistors']),1)
        self.assertAlmostEqual(d['resistors'][0]['L'],0.15e-6)
        self.assertTrue(d['_maa_conversion']['simulation_ready'])
    def test_ideal_capacitor(self):
        d,_=self.conv(['w2c,0,0,22,0'])
        self.assertAlmostEqual(d['resistors'][0]['C'],22e-12)
    def test_frequency_reactance(self):
        d,w=self.conv(['w2c,1,25,-100'])
        self.assertEqual(len(d['resistors']),1)
        self.assertGreater(d['resistors'][0]['C'],0)
        self.assertTrue(any('only at' in x for x in w))
    def test_finite_q_series_loss_at_design_frequency(self):
        d,w=self.conv(['w2c,0,0.15,0,150'])
        self.assertEqual(len(d['resistors']),1)
        self.assertGreater(d['resistors'][0]['R'],0)
        self.assertTrue(d['_maa_conversion']['simulation_ready'])

class TestPortSheetContact(unittest.TestCase):
    def test_port_ends_exactly_at_gap_faces(self):
        model=parse_maa(maa(['0,0,-1,0,0,1,0.001,-1'], ['w1c,0,1'],[]).encode(), 'a.maa')
        d,n,_,_=build_design(model,Path('a.maa'),5.)
        validate_design(d,n)
        a,b=d['parts'][0]['primitives']
        port=d['ports'][0]
        self.assertEqual(port['start'][2],a['points'][-1][2])
        self.assertEqual(port['stop'][2],b['points'][0][2])
        self.assertLess(a['points'][-1][2],b['points'][0][2])
        self.assertEqual(d['_maa_conversion']['original_sources'][0]['contact_overlap_mm'],0)

    def test_load_endpoints_exact(self):
        model=parse_maa(maa(['0,0,-1,0,0,1,0.001,-1'], [],['w1c,1,120,0']).encode(), 'a.maa')
        d,n,_,_=build_design(model,Path('a.maa'),5.)
        validate_design(d,n)
        self.assertEqual(d['resistors'][0]['start'][2],d['parts'][0]['primitives'][0]['points'][-1][2])
