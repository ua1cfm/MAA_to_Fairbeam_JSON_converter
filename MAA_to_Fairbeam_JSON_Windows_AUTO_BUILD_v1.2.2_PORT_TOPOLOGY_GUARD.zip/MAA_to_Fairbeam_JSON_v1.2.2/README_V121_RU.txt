MAA to Fairbeam v1.2.1 - verified changes (UA1CFM 2026)

Fixed globally: pure C or L exports no zero-valued R/L/C fields.
Existing zero-valued fields were rejected by Fairbeam Checks.
No fictitious parasitics have been introduced.

Validation: 30/30 Python unittest tests passed.
Full database: 1713 MAA files; 1709 JSON produced, 4 conversion errors.

QFH models verified against four uploaded original MAA files:
- QFH 145 / QFH 145-G / QFH 145 - 28: 2 wires of diameter 1.6 mm, 31 wires of diameter 6.0 mm. Retained.
- QFH PATTERN: 33 wires of diameter 1.6 mm. Retained.
- W1C and W1B/W1E of three QFH models still NOT_EXPORTED. Auto-segmentation and diagonal port handling require verified MMANA/Fairbeam electrical topology and cannot be reliably guessed.
- The successful JSON export or tests do NOT prove Fairbeam/openEMS electromagnetic coupling or impedance.

Run BUILD_EXE_WINDOWS.bat on Windows to build EXE.
CLI: python maa_to_fairbeam.py --input <folder-of-maa> --output <output-folder>
Use output conversion_report.csv and each JSON _maa_conversion to see failures.
