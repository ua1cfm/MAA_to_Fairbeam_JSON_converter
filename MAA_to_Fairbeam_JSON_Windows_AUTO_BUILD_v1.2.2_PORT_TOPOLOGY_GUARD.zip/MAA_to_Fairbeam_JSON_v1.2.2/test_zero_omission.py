import unittest
from pathlib import Path
from maa_to_fairbeam import Wire, place_electrical_components, validate_design

class ComponentEncodingTests(unittest.TestCase):
    def convert(self, load):
        m={'wires':[Wire((0.,0.,0.),(0.,0.,1.),0.003,11)],
           'sources':[],'loads':[load], 'frequency_mhz':145.0,'stack_section':None}
        wires,ports,elements,*_=place_electrical_components(m,list(m['wires']))
        self.assertEqual(len(elements),1)
        el=elements[0]
        self.assertTrue(all(el[k]>0 for k in ('R','L','C') if k in el))
        return el
    def test_pure_capacitor_omits_zero_r_l(self):
        e=self.convert('w1c,0,0,18,0')
        self.assertEqual(e['C'],18e-12)
        self.assertNotIn('R',e);self.assertNotIn('L',e)
    def test_pure_inductor_omits_zero_r_c(self):
        e=self.convert('w1c,0,0.1045,0,0')
        self.assertAlmostEqual(e['L'],0.1045e-6,places=15)
        self.assertNotIn('R',e);self.assertNotIn('C',e)
    def test_positive_resistor_omits_l_c(self):
        e=self.convert('w1c,1,50,0')
        self.assertEqual(e['R'],50)
        self.assertNotIn('L',e);self.assertNotIn('C',e)
    def test_finite_q_has_r_and_l(self):
        e=self.convert('w1c,0,0.1045,0,150')
        self.assertGreater(e['R'],0);self.assertGreater(e['L'],0)
        self.assertNotIn('C',e)
if __name__=='__main__':unittest.main()
