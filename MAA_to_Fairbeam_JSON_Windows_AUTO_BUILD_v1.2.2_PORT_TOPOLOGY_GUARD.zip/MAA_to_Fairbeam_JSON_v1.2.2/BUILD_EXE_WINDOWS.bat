﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title MAA to Fairbeam JSON - Windows EXE Builder - UA1CFM 2026

echo ================================================================
echo  MAA - Fairbeam JSON Converter v1.1.8
 echo  Windows EXE Builder - (c) UA1CFM 2026
 echo ================================================================
echo.
echo Checking Python 3...
set "PYTHON_BIN="
for /f "delims=" %%P in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON_BIN=%%P"
if not defined PYTHON_BIN for /f "delims=" %%P in ('python -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON_BIN=%%P"
if not defined PYTHON_BIN if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON_BIN=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYTHON_BIN if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYTHON_BIN=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYTHON_BIN if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" set "PYTHON_BIN=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"

if defined PYTHON_BIN goto :python_ok

echo Python was not found. Trying winget user-scope installation...
where winget >nul 2>&1
if errorlevel 1 goto :missing_python
winget install --id Python.Python.3.12 --exact --source winget --scope user --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto :missing_python
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON_BIN=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYTHON_BIN for /f "delims=" %%P in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON_BIN=%%P"
if not defined PYTHON_BIN goto :missing_python

:python_ok
echo Python: "%PYTHON_BIN%"
"%PYTHON_BIN%" -c "import sys, tkinter; assert sys.version_info >= (3,9); print('Tkinter OK')"
if errorlevel 1 goto :bad_python

echo.
echo Creating isolated build environment...
if not exist ".venv-win\Scripts\python.exe" (
    "%PYTHON_BIN%" -m venv ".venv-win"
    if errorlevel 1 goto :fail
)

set "BUILDER=.venv-win\Scripts\python.exe"
"%BUILDER%" -m pip --disable-pip-version-check install "pyinstaller>=6,<7"
if errorlevel 1 goto :pip_fail

echo.
echo Running regression tests...
"%BUILDER%" -m unittest discover -v
if errorlevel 1 goto :fail

echo.
echo Preparing version resource for PyInstaller spec directory...
if not exist "windows_version_info.txt" (
    echo ERROR: Missing windows_version_info.txt in the build folder.
    goto :fail
)
if not exist ".build_pyinstaller" mkdir ".build_pyinstaller"
if errorlevel 1 goto :fail
copy /Y "windows_version_info.txt" ".build_pyinstaller\windows_version_info.txt" >nul
if errorlevel 1 goto :fail

echo Compiling standalone Windows GUI executable...
"%BUILDER%" -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name "MAA_to_Fairbeam_JSON" ^
    --version-file "%~dp0windows_version_info.txt" ^
    --distpath "Windows_EXE" ^
    --workpath ".build_pyinstaller\work" ^
    --specpath ".build_pyinstaller" ^
    "maa_to_fairbeam.py"
if errorlevel 1 goto :fail
if not exist "Windows_EXE\MAA_to_Fairbeam_JSON.exe" goto :fail

copy /Y "README_WINDOWS_RU.txt" "Windows_EXE\README_WINDOWS_RU.txt" >nul
powershell -NoProfile -Command "Compress-Archive -LiteralPath 'Windows_EXE\MAA_to_Fairbeam_JSON.exe','Windows_EXE\README_WINDOWS_RU.txt' -DestinationPath 'MAA_to_Fairbeam_JSON_Windows_x64_PORTABLE.zip' -Force"
if errorlevel 1 echo WARNING: ZIP packing failed, but the EXE is ready.
echo.
echo ================================================================
echo SUCCESS: Windows_EXE\MAA_to_Fairbeam_JSON.exe
echo Portable ZIP: MAA_to_Fairbeam_JSON_Windows_x64_PORTABLE.zip
echo You may copy the EXE to any compatible Windows 10/11 PC.
echo ================================================================
echo.
choice /c YN /n /m "Launch the program now? [Y/N]: "
if errorlevel 2 goto :ok
start "" "Windows_EXE\MAA_to_Fairbeam_JSON.exe"
:ok
pause
exit /b 0

:missing_python
echo ERROR: Python 3.9+ with tkinter is required to BUILD the EXE.
echo Install Python 3 from https://www.python.org/downloads/windows/
echo Then run BUILD_EXE_WINDOWS.bat again. Python is NOT needed on target PCs.
goto :fail

:bad_python
echo ERROR: Python is too old or does not include tkinter.
goto :fail

:pip_fail
echo ERROR: Cannot install PyInstaller. Internet access is needed once.
echo Check the connection, then run the builder again.
goto :fail

:fail
echo.
echo Windows build failed. No successful EXE has been produced.
pause
exit /b 1
