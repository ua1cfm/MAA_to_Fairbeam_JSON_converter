#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MMANA-GAL MAA -> Fairbeam design/1 geometry batch converter.

Python 3.9+ stdlib only. GUI (tkinter) or CLI (--input / --output).
The supplied Fairbeam example specifies wire geometry but *not* the schema
of active ports or lumped loads. Ports and resistive loads use the confirmed project/1 field syntax.
Other MMANA source/load attributes are preserved verbatim; limitations are reported.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import queue
import re
import sys
import threading
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple

SCHEMA = 'fairbeam.design/1'
APP_VERSION = '1.2.2'
SUPPORTED_SUFFIXES = ('.design.json', '.json')
EPS_MM = 1e-6


@dataclass(frozen=True)
class Wire:
    start: Tuple[float, float, float]  # input meters
    end: Tuple[float, float, float]
    radius: float  # m, negative value denotes a taper specification key
    segmentation: float


class MaaError(ValueError):
    pass


def decode_maa(raw: bytes) -> Tuple[str, str]:
    # MMANA files have historically been saved in CP1251, sometimes CP866.
    for enc in ('utf-8-sig', 'cp1251'):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            pass
    return raw.decode('cp866', 'replace'), 'cp866 (replacement)'


def comma_numbers(line: str) -> List[float]:
    try:
        nums = [float(item.strip().replace('D+', 'E+').replace('D-', 'E-'))
                for item in line.split(',') if item.strip()]
    except ValueError as e:
        raise MaaError(f'Invalid numerical row: {line[:140]}') from e
    if not all(math.isfinite(v) for v in nums):
        raise MaaError(f'Non-finite numerical row: {line[:140]}')
    return nums


def section_key(line: str) -> Optional[str]:
    s = line.strip().lower()
    if not s:
        return None
    if 'установки комб' in s or 'taper wire set' in s:
        return 'taper'
    # Exact section recognition prevents accidental triggering on comments.
    ss = s.strip('* $\t .')
    if ss in ('wires', 'провода'):
        return 'wires'
    if ss in ('source', 'источ', 'источники'):
        return 'source'
    if ss in ('load', 'нагрузка', 'нагрузки'):
        return 'load'
    if ss in ('segmentation', 'автосегм', 'автосегментация'):
        return 'segmentation'
    if 'g/h/m/r/azel/x' in ss:
        return 'environment'
    if ss in ('comment', 'коммент'):
        return 'comment'
    if 'make stack' in ss or 'сделать стек' in ss:
        return 'stack'
    return None


def parse_maa(raw: bytes, source_name: str):
    text, encoding = decode_maa(raw)
    lines = text.splitlines()
    if len(lines) < 6:
        raise MaaError('File is too short for an MAA model')
    title = lines[0].strip() or Path(source_name).stem
    try:
        freq_mhz = float(lines[2].strip())
    except ValueError as e:
        raise MaaError('Invalid frequency in MAA header') from e
    if not math.isfinite(freq_mhz):
        raise MaaError('Frequency must be finite')
    sections = {}
    for i, line in enumerate(lines):
        key = section_key(line)
        if key and key not in sections:
            sections[key] = i
    if 'wires' not in sections:
        raise MaaError('Missing wire section (Wires/Провода)')

    def next_line(idx):
        j = idx
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            raise MaaError(f'Unexpected end at line {idx + 1}')
        return j

    start = next_line(sections['wires'] + 1)
    try:
        count_fields = comma_numbers(lines[start])
        count = int(count_fields[0])
        if count != count_fields[0]:
            raise ValueError('Wire count must be an integer')
    except (ValueError, IndexError) as e:
        raise MaaError('Invalid number of wires') from e
    stack = None
    if len(count_fields) >= 6:
        h, v = int(count_fields[1]), int(count_fields[2])
        hs, vs, posmode = count_fields[3], count_fields[4], int(count_fields[5])
        if 1 <= h <= 8 and 1 <= v <= 8 and 2 <= h*v <= 64 and hs >= 0 and vs >= 0:
            stack = (h, v, hs, vs, posmode)
    if not 0 < count <= 500000:
        raise MaaError('Wire count outside supported range 1..500000')
    wires: List[Wire] = []
    pos = start + 1
    for wi in range(count):
        pos = next_line(pos)
        values = comma_numbers(lines[pos])
        if len(values) != 8:
            raise MaaError(f'Wire {wi + 1}: expected 8 numeric values; got {len(values)}')
        wires.append(Wire(tuple(values[0:3]), tuple(values[3:6]), values[6], values[7]))
        pos += 1

    def section_rows(key):
        """Number of entries, raw records (keep source/load interpretations verbatim)."""
        if key not in sections:
            return [], False
        j = next_line(sections[key] + 1)
        header = comma_numbers(lines[j])
        if not header:
            raise MaaError(f'{key}: empty section header')
        count = int(header[0])
        if count < 0 or count > 500000:
            raise MaaError(f'{key}: unrealistic number of entries')
        rows = []
        j += 1
        for _ in range(count):
            j = next_line(j)
            if section_key(lines[j]):
                raise MaaError(f'{key}: section ended before all rows')
            rows.append(lines[j].strip())
            j += 1
        return rows, True

    sources, have_sources = section_rows('source')
    loads, have_loads = section_rows('load')
    tapers = {}
    if 'taper' in sections:
        raw_taper, _ = section_rows('taper')
        for line in raw_taper:
            vals = comma_numbers(line)
            if len(vals) < 4 or (len(vals) - 2) % 2:
                raise MaaError(f'Invalid taper table: {line[:160]}')
            key = abs(vals[0])
            mode = int(vals[1])
            stages = [(vals[k], abs(vals[k + 1])) for k in range(2, len(vals), 2)]
            if not 0 < key or mode not in (0, 1, 2, 3):
                raise MaaError(f'Invalid taper key/mode: {line[:160]}')
            if not stages or any(s[0] <= 0 or s[1] <= 0 for s in stages):
                raise MaaError(f'Invalid taper stage: {line[:160]}')
            tapers[key] = (mode, stages)

    environment = []
    if 'environment' in sections:
        j = next_line(sections['environment'] + 1)
        environment = comma_numbers(lines[j])
    return {
        'title': title, 'frequency_mhz': freq_mhz, 'wires': wires,
        'sources': sources, 'loads': loads, 'tapers': tapers,
        'environment': environment,
        'stack_section': stack,
        'encoding': encoding,
        'have_sources': have_sources, 'have_loads': have_loads,
    }


def near(p, q):
    return max(abs(a - b) for a, b in zip(p, q)) < EPS_MM


def interpolate(a, b, fraction):
    return tuple(a[k] + (b[k] - a[k]) * fraction for k in range(3))


def resolve_taper(w: Wire, tapers) -> List[Wire]:
    """Expand MMANA CombWire mode 0/2 (symmetric), 1/3 (from B to E).

    L0 means full center section length for center modes. Subsequent L values
    are lengths *on each side*; the sentinel >=9999 fills the remainder.
    """
    radius_key = abs(w.radius)
    matching = [(k, v) for k, v in tapers.items()
                if abs(k - radius_key) <= max(1e-9, k * 1e-6)]
    if len(matching) != 1:
        raise MaaError(f'Missing/ambiguous Taper wire set for radius key {w.radius}')
    mode, stages = matching[0][1]
    length = math.dist(w.start, w.end)
    if length <= 0:
        raise MaaError('Zero-length wire cannot be represented')
    spans = []  # meters along the original wire, start / end / radius
    if (mode & 1) == 0:
        center_len = min(length, stages[0][0])
        rem = max(0.0, (length - center_len) / 2.0)
        side = []
        idx = 1
        while rem > 1e-10:
            sl, sr = stages[min(idx, len(stages) - 1)]
            step = rem if sl >= 9999 or idx >= len(stages) - 1 else min(rem, sl)
            if step <= 0:
                raise MaaError('Invalid tapered-wire side length')
            side.append((step, sr))
            rem -= step
            idx += 1
        x = 0.0
        for sl, sr in reversed(side):
            spans.append((x, x + sl, sr))
            x += sl
        if center_len > 1e-10:
            spans.append((x, x + center_len, stages[0][1]))
            x += center_len
        for sl, sr in side:
            spans.append((x, min(length, x + sl), sr))
            x += sl
    else:
        x, idx = 0.0, 0
        while x < length - 1e-10:
            sl, sr = stages[min(idx, len(stages) - 1)]
            step = length - x if sl >= 9999 or idx >= len(stages) - 1 else min(length - x, sl)
            if step <= 0:
                raise MaaError('Invalid tapered-wire start-referenced length')
            spans.append((x, x + step, sr))
            x += step
            idx += 1
    result = []
    for x0, x1, rad in spans:
        if x1 - x0 > 1e-10:
            result.append(Wire(interpolate(w.start, w.end, x0 / length),
                               interpolate(w.start, w.end, x1 / length),
                               rad, w.segmentation))
    if not result:
        raise MaaError('Taper expansion yielded empty wire')
    if math.dist(result[0].start, w.start) > 1e-8 or math.dist(result[-1].end, w.end) > 1e-8:
        raise MaaError('Taper expansion did not preserve endpoints')
    return result


def expand_geometry(model, radius_zero_mm: float = 0.5):
    wires = []
    expanded_tapers = 0
    substituted = 0
    zero_length = 0
    for i, w in enumerate(model['wires'], 1):
        if math.dist(w.start, w.end) <= 1e-12:
            zero_length += 1
            continue
        if w.radius < 0:
            expanded = resolve_taper(w, model['tapers'])
            wires.extend(expanded)
            expanded_tapers += 1
        elif w.radius > 0:
            wires.append(w)
        else:
            substituted += 1
            wires.append(Wire(w.start, w.end, radius_zero_mm / 1000.0, w.segmentation))
    if not wires:
        raise MaaError('No finite-length wires to export')
    stack = model['stack_section']
    if stack:
        h, v, hs, vs, mode = stack
        original = wires
        wires = []
        for vi in range(v):
            dz = vi*vs if mode == 1 else (-vi*vs if mode == 2 else (vi - (v - 1)/2)*vs)
            for hi in range(h):
                dy = (hi - (h - 1)/2)*hs
                for w in original:
                    a, b = w.start, w.end
                    wires.append(Wire((a[0],a[1]+dy,a[2]+dz),(b[0],b[1]+dy,b[2]+dz),w.radius,w.segmentation))
    return wires, expanded_tapers, substituted, zero_length


def create_primitives(wires: List[Wire]):
    primitives = []
    for w in wires:
        a = [round(v * 1000.0, 9) for v in w.start]
        b = [round(v * 1000.0, 9) for v in w.end]
        radius = round(w.radius * 1000.0, 9)
        # Only consecutive MAA wires are joined. No heuristics connecting
        # distant segments: this preserves branching and the original geometry.
        if (primitives and abs(primitives[-1]['radius'] - radius) < 1e-9
                and near(primitives[-1]['points'][-1], a)):
            primitives[-1]['points'].append(b)
        else:
            primitives.append({'kind': 'wire', 'points': [a, b], 'radius': radius})
    return primitives


def safe_id(relative: Path):
    val = unicodedata.normalize('NFKD', str(relative.with_suffix('')))
    val = val.encode('ascii', 'ignore').decode('ascii').lower()
    val = re.sub(r'[^a-z0-9]+', '_', val).strip('_')[:60] or 'antenna'
    digest = hashlib.sha1(str(relative).encode('utf-8')).hexdigest()[:8]
    return f'{val}_{digest}'



# MMANA pulse positions: C/B/E with an integer pulse offset. The exact B/E
# locations require MMANA's auto-segmentation calculation, so they are NOT
# guessed. W#C0 is the geometric center and can be mapped without meshing.
PULSE_RE = re.compile(r'^w(\d+)([cbe])([+-]?\d+)?$', re.IGNORECASE)


def parse_pulse_name(value):
    match = PULSE_RE.fullmatch(value.strip())
    if not match:
        return None
    return (int(match.group(1)), match.group(2).upper(), int(match.group(3) or 0))


def parse_sources_and_loads(model):
    src_list, load_list, problems = [], [], []
    for i, raw in enumerate(model['sources'], 1):
        try:
            cols = [x.strip() for x in raw.split(',')]
            if len(cols) != 3 or not parse_pulse_name(cols[0]):
                raise ValueError('unexpected source fields or pulse name')
            phase, voltage = (float(v) for v in cols[1:])
            if not all(math.isfinite(v) for v in (phase, voltage)):
                raise ValueError('non-finite source')
            src_list.append({'index': i, 'pulse': cols[0], 'phase_deg': phase,
                             'voltage_v': voltage, 'raw': raw})
        except (ValueError, TypeError) as exc:
            problems.append('Source {}: {}'.format(i, exc))
            src_list.append({'index': i, 'raw': raw})
    for i, raw in enumerate(model['loads'], 1):
        try:
            cols = [x.strip() for x in raw.split(',')]
            if len(cols) not in (4, 5) or not parse_pulse_name(cols[0]):
                raise ValueError('unexpected load fields or pulse name')
            typ = int(cols[1]); nums = [float(x) for x in cols[2:]]
            if not all(math.isfinite(v) for v in nums):
                raise ValueError('non-finite load')
            entry = {'index': i, 'pulse': cols[0], 'maa_load_type': typ, 'raw': raw}
            if typ == 0 and len(nums) == 3:
                entry.update({'L_uH': nums[0], 'C_pF': nums[1], 'Q': nums[2]})
            elif typ == 1 and len(nums) == 2:
                entry.update({'R_ohm': nums[0], 'X_ohm': nums[1]})
            else:
                entry['parameters'] = nums
            load_list.append(entry)
        except (ValueError, TypeError) as exc:
            problems.append('Load {}: {}'.format(i, exc))
            load_list.append({'index': i, 'raw': raw})
    return src_list, load_list, problems


def inside_straight_cylinder(point, w: Wire, tolerance=1e-8):
    """True only inside the finite flat-ended cylinder, not a sphere around its tip.

    Using an endpoint-to-endpoint distance alone incorrectly flags an ordinary
    port sitting between the two flat ends of an axial conductor.
    """
    v = tuple(w.end[i] - w.start[i] for i in range(3))
    l2 = sum(x*x for x in v)
    if l2 < 1e-22 or w.radius <= 0:
        return False
    t = sum((point[i] - w.start[i])*v[i] for i in range(3))/l2
    if t < -1e-10 or t > 1 + 1e-10:
        return False
    closest = interpolate(w.start, w.end, max(0.0, min(1.0, t)))
    return math.dist(point, closest) < max(0.0, w.radius - tolerance)


def gap_hits_other_metal(start, stop, wires, excluded_index):
    """Conservative physical precheck on a proposed axial excitation gap."""
    for t in (0.15, 0.30, 0.5, 0.70, 0.85):
        test = interpolate(start, stop, t)
        for i, w in enumerate(wires):
            if i != excluded_index and inside_straight_cylinder(test, w):
                return i + 1
    return None


def gap_near_other_metal(start, stop, wires, excluded_index, margin=0.02):
    """Conservative capsule-envelope proximity check at an uncut source gap.

    Includes rounded endpoints unlike inside_straight_cylinder(). Near-touching
    conductors are unsafe for a FDTD lumped port without mesh verification.
    """
    for k, w in enumerate(wires):
        if k == excluded_index or w.radius <= 0:
            continue
        v = tuple(w.end[j] - w.start[j] for j in range(3))
        vv = sum(x*x for x in v)
        if vv <= 1e-20:
            continue
        for i in range(1, 20):
            p = interpolate(start, stop, i/20)
            t = max(0.0, min(1.0, sum((p[j]-w.start[j])*v[j] for j in range(3))/vv))
            d = math.dist(p, interpolate(w.start, w.end, t))
            if d <= w.radius*(1.0 + margin):
                return k+1
    return None


def port_axis_exact(start, stop, axis, tolerance=1e-6):
    a = 'xyz'.index(axis)
    return all(abs(start[k]-stop[k]) < tolerance for k in range(3) if k != a)


def pulse_position(original, pulse):
    """Return fractional coordinate of a MMANA segment centre, never an endcap.

    Exact index placement requires an explicit positive integral segment count.
    With automatic segmentation, the original centre (C0) remains geometric;
    other pulse positions are intentionally left unmapped.
    """
    parsed = parse_pulse_name(pulse)
    if not parsed:
        return None, 'invalid MMANA pulse name'
    number, kind, offset = parsed
    if not 1 <= number <= len(original):
        return None, 'wire number outside source model'
    wire = original[number - 1]
    if kind == 'C' and offset == 0:
        return 0.5, None
    nfloat = wire.segmentation
    n = round(nfloat)
    if not (n >= 1 and abs(nfloat - n) < 1e-8):
        return None, 'pulse {} needs explicit positive wire segmentation; auto segments cannot be guessed'.format(pulse)
    if kind == 'B':
        segment = offset
    elif kind == 'E':
        segment = n - 1 + offset
    else:
        # For even N, C0 straddles two adjacent segments; avoid an invented index.
        if n % 2 == 0:
            return None, 'ambiguous central pulse with even segment count on {}'.format(pulse)
        segment = n // 2 + offset
    if not 0 <= segment < n:
        return None, 'pulse {} lies outside {} segments'.format(pulse, n)
    return (segment + 0.5) / n, None


def create_gap_for_pulse(wires, pulse, used_segments):
    """Return (port endpoints mm, dominant axis, a list of metal wires with
    the center gap removed). Handles only center pulse WnC0; no silently
    approximated automatic segmentation or junction offsets.
    """
    pos = parse_pulse_name(pulse)
    if pos is None:
        return None, 'invalid MMANA pulse name'
    wire_index = pos[0]
    fraction, error = pulse_position(used_segments['original_wires'], pulse)
    if error:
        return None, error
    ow = used_segments['original_wires'][wire_index - 1]
    center = interpolate(ow.start, ow.end, fraction)
    candidates = []
    for i, w in enumerate(wires):
        delta = tuple(b-a for a,b in zip(w.start,w.end))
        length2 = sum(x*x for x in delta)
        if length2 <= 1e-16:
            continue
        t = sum((center[j] - w.start[j])*delta[j] for j in range(3))/length2
        projected = interpolate(w.start, w.end, t)
        error = math.dist(center,projected)
        if (0.03 < t < 0.97 and error < max(1e-8, 0.1*w.radius)
                and abs(sum(delta[j]*d for j,d in enumerate(delta))) > 0):
            candidates.append((error,i,t))
    if not candidates:
        return None, 'no unambiguous metal span containing center of {}'.format(pulse)
    candidates.sort()
    if len(candidates)>1 and abs(candidates[0][0]-candidates[1][0]) < 1e-10:
        return None, 'pulse overlaps multiple wire spans'
    _, index, t = candidates[0]
    w = wires[index]
    direction = tuple(w.end[k] - w.start[k] for k in range(3))
    axis_index = max(range(3), key=lambda k: abs(direction[k]))
    # Fairbeam lumped ports are strictly axis-directed. A diagonal gap with
    # direction="x" would be exported as a *box*, not as a tilted wire feed.
    # That box can cut through a neighboring thick tube (Big Star W17C).
    cross_axis = math.hypot(*(direction[k] for k in range(3) if k != axis_index))
    if cross_axis > 1e-7 * math.dist(w.start, w.end):
        return None, ('diagonal source span cannot be represented by a '
                      'Fairbeam x/y/z lumped port without changing the antenna; '
                      'NO artificial port generated')
    length = math.dist(w.start,w.end)
    # A small physical feed gap is necessary: a port over an uncut wire is
    # shorted by the wire and not an equivalent MMANA excitation.
    gap_m = min(max(2*w.radius,0.0005), length*0.10, 0.010)
    if gap_m < 1e-7:
        return None, 'gap too small to represent'
    h = gap_m/(2*length)
    if t-h<=0.0001 or t+h>=0.9999:
        return None, 'gap would intersect wire endpoint'
    left, right = interpolate(w.start,w.end,t-h), interpolate(w.start,w.end,t+h)
    # Crucial for short matching circuits: the proposed source can lie entirely
    # inside the *volume* of a different thick conductor. Example Big Star:
    # an oblique W17C feed at x,z ~5 mm is buried inside the 9 mm radius
    # 0..10 mm vertical W1. Merely cutting the thin line cannot unshort it.
    intruder = gap_near_other_metal(left, right, wires, index)
    if intruder is not None:
        return None, (f'port gap intersects or nearly touches another metal conductor (physical '
                      f'span {intruder}); no invalid shorted port generated')
    # Fairbeam validates a lumped port as a line/probe or sheet/strip.
    # The ends must lie on the conductor-gap faces, never inside the metal.
    # Prior revisions stretched the port into copper and produced a short.
    overlap = 0.0
    port_left, port_right = left, right
    part0,part1=Wire(w.start,left,w.radius,w.segmentation),Wire(right,w.end,w.radius,w.segmentation)
    axis = 'xyz'[axis_index]
    if not isinstance(used_segments['cut'],set):
        raise MaaError('Internal error: cut tracking')
    used_segments['cut'].add(index)
    # Replace without shifting other indexes. The original primitive is not
    # otherwise modified: two arms plus a true excitation gap.
    wires[index] = part0
    wires.append(part1)
    # A validated Fairbeam alternative is a one-dimensional axial probe.
    # Do not widen to a sheet here: sheets can intersect adjacent thick tubes
    # even when their centreline is clear (Twin Delta Loop regression).
    lo = [min(port_left[k], port_right[k]) for k in range(3)]
    hi = [max(port_left[k], port_right[k]) for k in range(3)]
    return {'start':[round(x*1000,9) for x in lo],
            'stop':[round(x*1000,9) for x in hi],
            'metal_gap_start':[round(x*1000,9) for x in left],
            'metal_gap_stop':[round(x*1000,9) for x in right],
            'contact_overlap_mm':0.0,
            'port_cross_section_mm':0.0,
            'direction':axis, 'gap_mm':round(gap_m*1000,6),
            'not_axis_aligned':False}, None


def place_electrical_components(model, phys_wires, port_r=50.0):
    """Map source and purely resistive load only where geometric placement is
    unambiguous. Preserve all original MAA electrical records in metadata.
    Returns separate wire geometry with actual gaps for mapped objects.
    """
    if not math.isfinite(port_r) or port_r<=0:
        raise MaaError('Port reference resistance must be positive')
    sources,loads,problems=parse_sources_and_loads(model)
    warnings=list(problems)
    portlist,resistors,wirelist = [],[],list(phys_wires)
    cut={'cut':set(),'original_wires':model['wires']}
    if model.get('stack_section'):
        if sources or loads:
            warnings.append('Make Stack: sources/loads preserved as original records; repeated port geometry not inferred')
        return wirelist,portlist,resistors,sources,loads,warnings
    # Map only the single ideal 0° source; multiple independent phase/amplitude
    # excitations cannot be represented by Fairbeam's boolean excite flag.
    if len(sources)>1:
        warnings.append('Multiple MMANA sources: relative excitation phase/amplitude cannot be represented by the confirmed Fairbeam port fields')
    for s in sources:
        if len(sources) != 1 or s.get('index') != 1 or not math.isfinite(s.get('voltage_v', float('nan'))) or abs(s.get('voltage_v', 0.0)) < 1e-15:
            s['mapping']='NOT_EXPORTED'
            s['mapping_issue']='multiple simultaneous sources or zero-voltage source cannot be represented by a single normalized Fairbeam excitation'
            warnings.append('Source {} ({}): {}'.format(s['index'],s.get('pulse', '?'),s['mapping_issue']))
            continue
        box, err=create_gap_for_pulse(wirelist,s['pulse'],cut)
        if err:
            s['mapping'] = 'NOT_EXPORTED'
            s['mapping_issue'] = err
            warnings.append('Source {} ({}): {}'.format(s['index'],s.get('pulse','?'),err))
            continue
        portlist.append({'number':1,'type':'lumped','R':port_r,
                         'direction':box['direction'],'start':box['start'],
                         'stop':box['stop'],'excite':True})
        s['mapping']='gap_port'
        s['excitation_normalized']=True
        s['original_voltage_v']=s['voltage_v']
        s['original_phase_deg']=s['phase_deg']
        if s['voltage_v'] != 1 or s['phase_deg'] != 0:
            warnings.append('Single source voltage and absolute phase normalized to Fairbeam excitation; S-parameters unchanged for a linear single-source system, absolute fields/current scales differ')
        s['port_r_ohm']=port_r
        s['gap_mm']=box['gap_mm']
        s['contact_overlap_mm']=box['contact_overlap_mm']
        s['port_cross_section_mm']=box['port_cross_section_mm']
        warnings.append('MMANA voltage source represented by normalized {}-ohm lumped port: absolute drive voltage is not preserved'.format(port_r))
    for load in loads:
        # Fairbeam 0.7+ supports R/L/C combinations in the existing
        # `resistors` array (SI units, topology=series|parallel).
        # A complex constant impedance in MMANA is matched only at f0;
        # a passive physical R/L/C is NOT a broadband constant reactance.
        r, inductance, capacitance = 0.0, 0.0, 0.0
        if load.get('maa_load_type') == 0:
            inductance = load.get('L_uH', 0.0) * 1e-6
            capacitance = load.get('C_pF', 0.0) * 1e-12
            q = load.get('Q', 0)
            if q > 0:
                # Equivalent SERIES loss at the design frequency, NOT an
                # assertion of broadband MMANA equivalence. Q = |X| / Rs.
                # For a series L+C the net reactance determines series Q.
                f0 = model['frequency_mhz'] * 1e6
                if not math.isfinite(f0) or f0 <= 0:
                    load['mapping'] = 'NOT_EXPORTED'
                    load['mapping_issue'] = 'finite-Q equivalent requires positive frequency'
                    warnings.append('Load {} ({}): {}'.format(load['index'], load.get('pulse', '?'), load['mapping_issue']))
                    continue
                omega = 2 * math.pi * f0
                reactance = (omega * inductance if inductance > 0 else 0.0) - (1 / (omega * capacitance) if capacitance > 0 else 0.0)
                if abs(reactance) < 1e-12:
                    load['mapping'] = 'NOT_EXPORTED'
                    load['mapping_issue'] = 'finite-Q equivalent undefined at LC series resonance'
                    warnings.append('Load {} ({}): {}'.format(load['index'], load.get('pulse', '?'), load['mapping_issue']))
                    continue
                r = abs(reactance) / q
                load['series_loss_R_ohm_at_f0'] = r
                load['loss_reference_frequency_mhz'] = model['frequency_mhz']
                load['loss_model'] = 'series Rs=abs(X_L+X_C)/Q at f0; approximate'
                warnings.append('Load {} ({}): finite Q={} -> series Rs={:.8g} ohm at {:.8g} MHz ONLY; no broadband Q equivalence'.format(load['index'], load.get('pulse', '?'), q, r, model['frequency_mhz']))
        elif load.get('maa_load_type') == 1:
            r=load.get('R_ohm',0.0)
            x=load.get('X_ohm',0.0)
            f=model['frequency_mhz']*1e6
            if x and f<=0:
                load['mapping']='NOT_EXPORTED'
                load['mapping_issue']='reactance conversion requires positive design frequency'
                warnings.append('Load {}: {}'.format(load['index'],load['mapping_issue']))
                continue
            if x>0:
                inductance=x/(2*math.pi*f)
            elif x<0:
                capacitance=-1/(2*math.pi*f*x)
            if x:
                warnings.append('Load {} ({}): R+jX represented by a SERIES RLC matching only at {:.6g} MHz, not constant reactance'.format(load['index'],load.get('pulse','?'),model['frequency_mhz']))
        else:
            load['mapping']='NOT_EXPORTED'
            load['mapping_issue']='unknown MMANA load type'
            warnings.append('Load {}: {}'.format(load['index'],load['mapping_issue']))
            continue
        if any(not math.isfinite(v) or v<0 for v in (r,inductance,capacitance)) or not any(v>0 for v in (r,inductance,capacitance)):
            load['mapping']='NOT_EXPORTED'
            load['mapping_issue']='no passive positive R/L/C equivalent'
            warnings.append('Load {}: {}'.format(load['index'],load['mapping_issue']))
            continue
        box,err=create_gap_for_pulse(wirelist,load['pulse'],cut)
        if err:
            load['mapping']='NOT_EXPORTED'
            load['mapping_issue']=err
            warnings.append('Load {} ({}): {}'.format(load['index'],load.get('pulse','?'),err))
            continue
        element={'name':'maa_load_{}'.format(load['index']),
            'label':'MMANA load {} ({})'.format(load['index'],load['pulse']),
            'type':'resistor',
            'direction':box['direction'],'start':box['start'],'stop':box['stop']}
        # Fairbeam rejects explicit zero-valued R/L/C fields. An ideal capacitor
        # must therefore contain C only, not R=0 and L=0.
        if r > 0:
            element['R'] = r
        if inductance > 0:
            element['L'] = inductance
        if capacitance > 0:
            element['C'] = capacitance
        if inductance>0 or capacitance>0:
            element['topology']='series'
        resistors.append(element)
        load['mapping']='gap_series_rlc'
        load['gap_mm']=box['gap_mm']
        load['contact_overlap_mm']=box['contact_overlap_mm']
        load['port_cross_section_mm']=box['port_cross_section_mm']
    return wirelist,portlist,resistors,sources,loads,warnings


def build_design(model, relative: Path, sweep_percent: float, radius_zero_mm: float = 0.5, port_r: float = 50.0):
    phys_wires, expanded, substituted, zero_length = expand_geometry(model, radius_zero_mm)
    wires, ports, resistors, src_data, load_data, electrical_warnings = place_electrical_components(model, phys_wires, port_r)
    primitives = create_primitives(wires)
    radii = {round(w.radius * 1000.0, 9) for w in phys_wires}
    params = []
    if len(radii) == 1:
        params = [{'key': 'wire_radius', 'default': next(iter(radii)),
                   'unit': 'mm', 'label': 'Conductor radius'}]
    has_frequency = model['frequency_mhz'] > 0
    f_ghz = model['frequency_mhz'] / 1000.0 if has_frequency else 2.0
    fp = sweep_percent / 100
    design = {
        'schema': SCHEMA,
        'model': {'id': safe_id(relative), 'name': model['title']},
        'params': params,
        'simulation': {'f_min': round(f_ghz * (1 - fp), 12) if has_frequency else 1.0,
                       'f_max': round(f_ghz * (1 + fp), 12) if has_frequency else 3.0,
                       'boundaries': 'MUR', 'end_criteria_db': -40},
        'materials': [{'name': 'copper', 'kind': 'metal'}],
        'parts': [{'name': 'antenna', 'material': 'copper', 'primitives': primitives}],
        'ports': ports,
        'resistors': resistors,
        'mesh': {'mode': 'auto', 'cells_per_wavelength': 20},
        'far_field': {'enabled': has_frequency,
                      'frequencies': [round(f_ghz, 12)] if has_frequency else []},
    }
    # Per-record audit: never claim an electrically faithful Fairbeam project
    # when a source or a load was preserved as metadata only.
    connection_audit = []
    for category, entries in (('source', src_data), ('load', load_data)):
        for entry in entries:
            parsed = parse_pulse_name(entry.get('pulse', ''))
            wire_num = parsed[0] if parsed else None
            point_mm = None
            axis_start_mm = axis_end_mm = None
            if wire_num is not None and 1 <= wire_num <= len(model['wires']):
                wire = model['wires'][wire_num - 1]
                frac, perr = pulse_position(model['wires'], entry.get('pulse', ''))
                if perr is None:
                    point_mm = [round(z * 1000, 6) for z in interpolate(wire.start, wire.end, frac)]
                axis_start_mm = [round(z * 1000, 6) for z in wire.start]
                axis_end_mm = [round(z * 1000, 6) for z in wire.end]
            internal_metal = []
            if point_mm is not None:
                center_m = tuple(x / 1000 for x in point_mm)
                for other_num, other_wire in enumerate(phys_wires, 1):
                    # Exclude nominal source wire by geometric comparison: a
                    # separate conductor containing the contact point matters.
                    if (wire_num is not None and wire_num <= len(model['wires'])
                        and other_wire == model['wires'][wire_num - 1]):
                        continue
                    if inside_straight_cylinder(center_m, other_wire):
                        internal_metal.append(other_num)
            connection_audit.append({
                'kind': category,
                'pulse': entry.get('pulse'),
                'source_wire_number': wire_num,
                'center_mm': point_mm,
                'wire_start_mm': axis_start_mm,
                'wire_end_mm': axis_end_mm,
                'mapping': entry.get('mapping', 'NOT_EXPORTED'),
                'issue': entry.get('mapping_issue'),
                'inside_other_physical_wires': internal_metal,
            })
    design['_maa_conversion'] = {
        'original_frequency_mhz': model['frequency_mhz'],
        'electrical_connection_audit': connection_audit,
        'original_sources': src_data,
        'original_loads': load_data,
        'maa_ground_settings': model['environment'],
        'maa_stack_parameters': model['stack_section'],
        'mapping_note': 'Ideal pure-C/L loads omit zero-valued R/L/C keys to pass Fairbeam Checks. Original MAA records retained. Ports default to an axial line probe without transverse extent, with endpoints on metal gap faces; geometry is checked for shunting metal. Verify Fairbeam port coupling on the actual solver grid.  Axis-aligned, non-shorted source pulses and passive loads can be exported across genuine conductor gaps; finite-Q loads, auto-segmented end pulses, diagonal feeds, phased simultaneous sources, stack excitation and MMANA ground remain unsupported. R+jX physical RLC approximates X only at design frequency. Review Fairbeam checks and mesh convergence.',
        'converter_version': APP_VERSION,
        'electrical_elements_exported': len(ports) + len(resistors),
        'electrical_elements_expected': len(src_data) + len(load_data),
        'simulation_ready': bool(ports and len(ports) == len(src_data)
                                 and len(resistors) == len(load_data)
                                 and not any(x.get('mapping') == 'NOT_EXPORTED'
                                             for x in src_data + load_data)
                                 and (not model['environment'] or
                                      (model['environment'][0] == 0 and
                                       (len(model['environment']) < 2 or model['environment'][1] == 0) and
                                       (len(model['environment']) < 3 or model['environment'][2] == 1)))),
    }
    warnings = list(electrical_warnings)
    if src_data and not ports:
        warnings.append('NOT SIMULATION READY: no valid excited port was mapped; '
                        'edit feed geometry manually in Fairbeam')
    if len(resistors) != len(load_data):
        warnings.append('NOT ELECTRICALLY EQUIVALENT: some MMANA loads could not be converted')
    if not has_frequency:
        warnings.append('MAA frequency <= 0: Far Field disabled, placeholder simulation range 1..3 GHz; set manually')
    if substituted:
        warnings.append(f'{substituted} zero-radius wire(s): visualization-only radius {radius_zero_mm} mm substituted')
    if zero_length:
        warnings.append(f'{zero_length} zero-length wire(s) omitted because they have no physical geometry')
    if not model['have_sources'] or not model['have_loads']:
        warnings.append('Incomplete source/load section: check original MAA')
    env = model['environment']
    if env and (env[0] != 0 or (len(env) > 1 and env[1] != 0)):
        warnings.append('MAA ground/height NOT mapped: unsupported by supplied example')
    if env and len(env) >= 3 and env[2] != 1:
        warnings.append('MAA material choice NOT mapped: copper used as in example')
    if model['stack_section']:
        h, v, *_ = model['stack_section']
        warnings.append(f'Make Stack geometry expanded {h} x {v}; excitation not mapped')
    if expanded:
        warnings.append(f'{expanded} tapered wire(s) expanded via CombWire/Taper table')
    return design, sum(len(p['points'])-1 for p in primitives), len(primitives), warnings


def validate_design(design, expected_wires):
    if design['schema'] != SCHEMA:
        raise MaaError('Invalid output schema')
    primitives = design['parts'][0]['primitives']
    n = 0
    for prim in primitives:
        if prim['kind'] != 'wire' or len(prim['points']) < 2:
            raise MaaError('Invalid output primitive')
        if prim['radius'] <= 0:
            raise MaaError('Non-positive radius in output')
        for p in prim['points']:
            if len(p) != 3 or not all(math.isfinite(v) for v in p):
                raise MaaError('Invalid coordinate')
        n += len(prim['points']) - 1
    if n != expected_wires:
        raise MaaError(f'Output lost geometry segments: {n}/{expected_wires}')
    for port in design.get('ports', []):
        if not (port['R']>0 and port['type']=='lumped' and port['direction'] in 'xyz'):
            raise MaaError('Invalid port')
        if math.dist(port['start'], port['stop'])<=0:
            raise MaaError('Zero-length port')
        ax='xyz'.index(port['direction'])
        if port['stop'][ax] <= port['start'][ax] or any(
                port['stop'][k] < port['start'][k] for k in range(3) if k != ax):
            raise MaaError('Lumped port must have nonzero axial extent')
        transverse = [k for k in range(3) if k != ax]
        if sum(port['stop'][k] > port['start'][k] for k in transverse) > 1:
            raise MaaError('Fairbeam lumped port must be a line or sheet, not a volume')

        for fraction in (0.25, 0.5, 0.75):
            point = interpolate(port['start'], port['stop'], fraction)
            for prim in primitives:
                radius = prim['radius']
                for a, b in zip(prim['points'][:-1], prim['points'][1:]):
                    w = Wire(tuple(a), tuple(b), radius, 0.)
                    # This is only a high-confidence *inner-volume* check.
                    # Tube intersections at faces are left for Fairbeam Checks.
                    if inside_straight_cylinder(point, w, tolerance=1e-5):
                        raise MaaError('Port interior lies inside wire metal '
                                       '(invalid Fairbeam port-in-metal)')
    for el in design.get('resistors', []):
        if not (any(el.get(k,0)>0 for k in ('R','L','C')) and all(el[k]>0 for k in ('R','L','C') if k in el) and el['type']=='resistor' and el['direction'] in 'xyz'):
            raise MaaError('Invalid resistor')
    if design['simulation']['f_min'] <= 0:
        raise MaaError('Simulation minimum frequency must be positive')


def enumerate_files(src: Path):
    return sorted((p for p in src.rglob('*') if p.is_file() and p.suffix.lower() == '.maa'),
                  key=lambda p: str(p.relative_to(src)).casefold())


def process_batch(src: Path, dst: Path, suffix='.design.json', overwrite=False,
                  sweep_percent=5.0, radius_zero_mm=0.5, progress: Optional[Callable] = None,
                  stop_event: Optional[threading.Event] = None, port_r:float=50.0):
    if suffix not in SUPPORTED_SUFFIXES:
        raise MaaError('Use suffix .design.json or .json')
    if src.resolve() == dst.resolve():
        raise MaaError('Input and output folders must be different')
    if not src.is_dir():
        raise MaaError('Input folder does not exist')
    if not 0 < sweep_percent < 99:
        raise MaaError('Sweep percentage must be between 0 and 99')
    if not math.isfinite(radius_zero_mm) or radius_zero_mm <= 0:
        raise MaaError('Visualization radius for zero-radius MAA wires must be positive')
    files = enumerate_files(src)
    if not files:
        raise MaaError('No .MAA files found')
    dst.mkdir(parents=True, exist_ok=True)
    stats = {'OK': 0, 'WARNING': 0, 'SKIPPED': 0, 'ERROR': 0, 'CANCELLED': 0}
    records = []
    report = dst / 'conversion_report.csv'
    fieldnames = ['status', 'source', 'output', 'maa_wires', 'physical_segments',
                  'json_primitives', 'sources', 'loads', 'warnings_or_error']
    with report.open('w', newline='', encoding='utf-8-sig', errors='backslashreplace') as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for index, src_file in enumerate(files, 1):
            if stop_event is not None and stop_event.is_set():
                stats['CANCELLED'] = len(files) - index + 1
                break
            relative = src_file.relative_to(src)
            safe_relative = Path(''.join(chr(ord(c)) if not 0xDC80 <= ord(c) <= 0xDCFF else '_' for c in str(relative)))
            out_file = dst / safe_relative.parent / (safe_relative.stem + suffix)
            record = {'status': '', 'source': relative.as_posix(),
                      'output': out_file.relative_to(dst).as_posix(),
                      'maa_wires': '', 'physical_segments': '',
                      'json_primitives': '', 'sources': '', 'loads': '',
                      'warnings_or_error': ''}
            try:
                if out_file.exists() and not overwrite:
                    record['status'] = 'SKIPPED'
                    record['warnings_or_error'] = 'Output already exists (overwrite unchecked)'
                else:
                    model = parse_maa(src_file.read_bytes(), safe_relative.name)
                    design, nsegments, nprims, warnings = build_design(model, safe_relative, sweep_percent, radius_zero_mm, port_r)
                    validate_design(design, nsegments)
                    # Do not partially overwrite a pre-existing valid file on interruption.
                    out_file.parent.mkdir(parents=True, exist_ok=True)
                    tmp = out_file.with_name(out_file.name + '.tmp')
                    try:
                        tmp.write_text(json.dumps(design, ensure_ascii=False, indent=2,
                                                  allow_nan=False) + '\n', encoding='utf-8')
                        with tmp.open(encoding='utf-8') as verify:
                            check = json.load(verify)
                        validate_design(check, nsegments)
                        tmp.replace(out_file)
                    finally:
                        if tmp.exists():
                            tmp.unlink()
                    record.update({'status': ('WARNING' if not design['_maa_conversion']['simulation_ready'] or warnings else 'OK'),
                                   'maa_wires': len(model['wires']),
                                   'physical_segments': nsegments,
                                   'json_primitives': nprims,
                                   'sources': len(model['sources']), 'loads': len(model['loads']),
                                   'warnings_or_error': '; '.join(warnings)})
            except (OSError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
                record['status'] = 'ERROR'
                record['warnings_or_error'] = str(exc)
            stats[record['status']] += 1
            records.append(record)
            writer.writerow(record)
            fh.flush()
            if progress:
                progress(index, len(files), record)
    return {'total': len(files), 'done': len(records), 'stats': stats,
            'report': str(report), 'records': records}


def launch_gui():
    try:
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
    except ImportError:
        print('tkinter is unavailable; use CLI --input/--output.', file=sys.stderr)
        sys.exit(2)

    root = tk.Tk()
    root.title('MAA -> Fairbeam JSON | Batch Converter ' + APP_VERSION)
    root.geometry('870x620')
    root.minsize(720, 500)
    root.columnconfigure(1, weight=1)
    src_var = tk.StringVar()
    dst_var = tk.StringVar()
    suffix_var = tk.StringVar(value='.design.json')
    radius_var = tk.StringVar(value='0.5')
    port_r_var = tk.StringVar(value='50')
    overwrite_var = tk.BooleanVar(value=False)
    status_var = tk.StringVar(value='Select the folder containing MAA files.')
    count_var = tk.StringVar(value='0 / 0')
    q = queue.Queue()
    stop = threading.Event()
    active = [False]

    def browse(which):
        var = src_var if which == 'src' else dst_var
        folder = filedialog.askdirectory(initialdir=var.get() or str(Path.home()))
        if folder:
            var.set(folder)

    padding = {'padx': 12, 'pady': 7}
    ttk.Label(root, text='Source folder (*.MAA, including all subfolders)').grid(row=0, column=0, sticky='w', **padding)
    ttk.Entry(root, textvariable=src_var).grid(row=0, column=1, sticky='ew', **padding)
    ttk.Button(root, text='Browse...', command=lambda: browse('src')).grid(row=0, column=2, **padding)
    ttk.Label(root, text='Output folder (same subfolder structure)').grid(row=1, column=0, sticky='w', **padding)
    ttk.Entry(root, textvariable=dst_var).grid(row=1, column=1, sticky='ew', **padding)
    ttk.Button(root, text='Browse...', command=lambda: browse('dst')).grid(row=1, column=2, **padding)
    opts = ttk.Frame(root)
    opts.grid(row=2, column=0, columnspan=3, sticky='w', **padding)
    ttk.Label(opts, text='Output extension:').pack(side='left', padx=(0, 8))
    ttk.Combobox(opts, textvariable=suffix_var, values=SUPPORTED_SUFFIXES, width=16,
                 state='readonly').pack(side='left')
    ttk.Checkbutton(opts, text='Overwrite existing JSON', variable=overwrite_var).pack(side='left', padx=18)
    ttk.Label(opts, text='Fallback radius (mm):').pack(side='left', padx=(6,4))
    ttk.Entry(opts, textvariable=radius_var, width=7).pack(side='left')
    ttk.Label(opts,text=' Port Z0 (ohm):').pack(side='left', padx=(14,3))
    ttk.Entry(opts,textvariable=port_r_var,width=7).pack(side='left')
    progressbar = ttk.Progressbar(root, mode='determinate', maximum=100)
    progressbar.grid(row=3, column=0, columnspan=3, sticky='ew', padx=12, pady=(12, 4))
    tt = ttk.Frame(root)
    tt.grid(row=4, column=0, columnspan=3, sticky='ew', padx=12, pady=3)
    ttk.Label(tt, textvariable=count_var, width=13).pack(side='left')
    ttk.Label(tt, textvariable=status_var).pack(side='left', fill='x', expand=True)

    log = tk.Text(root, height=17, state='disabled', wrap='none', font=('Consolas', 9))
    log.grid(row=5, column=0, columnspan=3, sticky='nsew', padx=(12, 0), pady=10)
    scrollbar = ttk.Scrollbar(root, command=log.yview)
    scrollbar.grid(row=5, column=3, sticky='ns', pady=10, padx=(0, 12))
    log.configure(yscrollcommand=scrollbar.set)
    root.rowconfigure(5, weight=1)

    def add_line(msg):
        log.configure(state='normal')
        log.insert('end', msg + '\n')
        log.see('end')
        log.configure(state='disabled')

    def begin():
        if active[0]:
            return
        a, b = src_var.get().strip(), dst_var.get().strip()
        if not a or not b or not Path(a).is_dir():
            messagebox.showerror('Invalid paths', 'Choose an existing MAA folder and an output folder.')
            return
        if Path(a).resolve() == Path(b).resolve():
            messagebox.showerror('Invalid paths', 'Use different input and output folders.')
            return
        try:
            fallback_radius = float(radius_var.get().strip().replace(',', '.'))
            if not math.isfinite(fallback_radius) or fallback_radius <= 0:
                raise ValueError()
        except ValueError:
            messagebox.showerror('Invalid radius', 'Fallback radius must be a positive number in mm.')
            return
        try:
            resistance=float(port_r_var.get().strip().replace(',', '.'))
            if not math.isfinite(resistance) or resistance<=0:
                raise ValueError()
        except ValueError:
            messagebox.showerror('Invalid port resistance','Port Z0 must be positive')
            return
        suffix = suffix_var.get()
        overwrite = overwrite_var.get()
        active[0] = True
        stop.clear()
        start_btn.config(state='disabled')
        cancel_btn.config(state='normal')
        progressbar['value'] = 0
        status_var.set('Scanning MAA files...')
        add_line('-' * 74)
        def worker():
            try:
                result = process_batch(Path(a), Path(b), suffix, overwrite,
                                       radius_zero_mm=fallback_radius, progress=lambda i,n,r: q.put(('progress', i, n, r)), stop_event=stop, port_r=resistance)
                q.put(('complete', result))
            except Exception as e:
                q.put(('failed', str(e)))
        threading.Thread(target=worker, daemon=True).start()

    def cancel():
        stop.set()
        status_var.set('Stopping after the current file...')
        cancel_btn.config(state='disabled')

    def poll():
        try:
            while True:
                event = q.get_nowait()
                if event[0] == 'progress':
                    _, i, n, r = event
                    progressbar['value'] = 100.0 * i / n
                    count_var.set(f'{i} / {n}')
                    status_var.set(r['source'])
                    symbol = {'OK': 'OK', 'WARNING': 'WARN', 'ERROR': 'ERROR', 'SKIPPED': 'SKIP'}[r['status']]
                    add_line(f'[{i}/{n}] {symbol:5} {r["source"]} -> {r["output"]}')
                    if r['status'] in ('ERROR', 'WARNING'):
                        add_line('    ' + r['warnings_or_error'])
                elif event[0] == 'complete':
                    result = event[1]
                    active[0] = False
                    start_btn.config(state='normal')
                    cancel_btn.config(state='disabled')
                    info = ', '.join(f'{k}: {v}' for k,v in result['stats'].items() if v)
                    status_var.set('Finished: ' + info)
                    add_line(f'FINISHED. {info}\nReport: {result["report"]}')
                    messagebox.showinfo('Batch complete', info + '\n\nCSV report saved in output folder.')
                elif event[0] == 'failed':
                    active[0] = False
                    start_btn.config(state='normal')
                    cancel_btn.config(state='disabled')
                    status_var.set('Error')
                    add_line('ERROR: ' + event[1])
                    messagebox.showerror('Batch error', event[1])
        except queue.Empty:
            pass
        root.after(100, poll)

    buttons = ttk.Frame(root)
    buttons.grid(row=6, column=0, columnspan=3, pady=8)
    start_btn = ttk.Button(buttons, text='Convert all MAA -> JSON', command=begin)
    start_btn.pack(side='left', padx=8)
    cancel_btn = ttk.Button(buttons, text='Stop after current file', command=cancel, state='disabled')
    cancel_btn.pack(side='left', padx=8)
    ttk.Button(buttons, text='Exit', command=root.destroy).pack(side='left', padx=8)
    ttk.Label(root, text='© UA1CFM, 2026', font=('Segoe UI',10,'bold'), foreground='#606060').grid(row=7,column=0,columnspan=3,sticky='e',padx=18,pady=(0,8))
    root.after(100, poll)
    root.mainloop()


def main(argv=None):
    parser = argparse.ArgumentParser(description='MMANA-GAL MAA to Fairbeam JSON batch converter')
    parser.add_argument('--input', help='MAA source folder (searched recursively)')
    parser.add_argument('--output', help='JSON destination folder')
    parser.add_argument('--suffix', choices=SUPPORTED_SUFFIXES, default='.design.json',
                        help='Output extension (default .design.json)')
    parser.add_argument('--overwrite', action='store_true', help='Overwrite existing JSON files')
    parser.add_argument('--radius-zero-mm', type=float, default=0.5,
                        help='Visualization-only radius for MAA wires whose radius is zero (default 0.5 mm)')
    parser.add_argument('--port-r', type=float, default=50.0, help='Fairbeam lumped-port Z0, ohm (default 50)')
    parser.add_argument('--sweep-percent', type=float, default=5.0,
                        help='Simulation range +/- percentage around MAA frequency (default 5)')
    args = parser.parse_args(argv)
    if args.input or args.output:
        if not args.input or not args.output:
            parser.error('Both --input and --output are required')
        try:
            result = process_batch(Path(args.input), Path(args.output), args.suffix,
                                   args.overwrite, args.sweep_percent, args.radius_zero_mm,
                                   progress=lambda i,n,r: print(f'{i}/{n} [{r["status"]}] {r["source"]}: {r["warnings_or_error"]}', flush=True), port_r=args.port_r)
        except MaaError as e:
            print(f'ERROR: {e}', file=sys.stderr)
            return 2
        print('FINISHED:', result['stats'], 'CSV report:', result['report'])
        return 1 if result['stats']['ERROR'] else 0
    launch_gui()
    return 0


if __name__ == '__main__':
    sys.exit(main())
