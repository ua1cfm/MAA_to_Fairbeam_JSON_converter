import unittest
from pathlib import Path
from maa_to_fairbeam import parse_maa, build_design, validate_design, pulse_position


def design(source, segmentation=11, loads=()):
    rows=['TEST','*','145','***Wires***','1', f'0,0,-1,0,0,1,0.001,{segmentation}',
          '***Source***',str(bool(source) and 1 or 0)+',0']
    if source: rows.append(source)
    rows.extend(['***Load***',str(len(loads))+',1',*loads,'***Segmentation***','400,40,2,2',
                 '***G/H/M/R/AzEl/X***','0,0,1,50,120,60,0',''])
    model=parse_maa('\n'.join(rows).encode(),'test.maa')
    d,n,_,_=build_design(model,Path('test.maa'),5.)
    validate_design(d,n)
    return d

class PulseTests(unittest.TestCase):
    def test_b0_first_segment(self):
        d=design('w1b,0,1')
        self.assertEqual(len(d['ports']),1)
        mid=(d['ports'][0]['start'][2]+d['ports'][0]['stop'][2])/2
        self.assertAlmostEqual(mid,-1000+2000/22,places=3)
    def test_e0_last_segment(self):
        d=design('w1e,0,1')
        self.assertEqual(len(d['ports']),1)
        mid=(d['ports'][0]['start'][2]+d['ports'][0]['stop'][2])/2
        self.assertAlmostEqual(mid,1000-2000/22,places=3)
    def test_center_offset(self):
        d=design('w1c+2,0,1')
        self.assertEqual(len(d['ports']),1)
        self.assertAlmostEqual((d['ports'][0]['start'][2]+d['ports'][0]['stop'][2])/2,2000*2/11,places=3)
    def test_auto_end_rejected(self):
        d=design('w1b,0,1',-1)
        self.assertFalse(d['ports'])
        self.assertFalse(d['_maa_conversion']['simulation_ready'])
    def test_even_center_offset_rejected(self):
        d=design('w1c+1,0,1',10)
        self.assertFalse(d['ports'])
    def test_multiple_load_same_wire(self):
        d=design('',11,['w1b,1,20,0','w1e,1,30,0'])
        self.assertEqual(len(d['resistors']),2)

if __name__=='__main__': unittest.main()

class SingleFeedNormalizationTests(unittest.TestCase):
    def test_nonunit_source_is_normalized(self):
        d=design('w1c,45,2.5')
        self.assertEqual(len(d['ports']),1)
        entry=d['_maa_conversion']['original_sources'][0]
        self.assertEqual(entry['mapping'],'gap_port')
        self.assertEqual(entry['original_phase_deg'],45)
        self.assertEqual(entry['original_voltage_v'],2.5)
        self.assertTrue(entry['excitation_normalized'])

    def test_zero_voltage_not_excited(self):
        d=design('w1c,0,0')
        self.assertEqual(len(d['ports']),0)
